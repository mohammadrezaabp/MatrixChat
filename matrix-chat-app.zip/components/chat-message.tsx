'use client'

interface ChatMessageProps {
  role: 'user' | 'assistant'
  content: string
  isLoading?: boolean
}

export function ChatMessage({ role, content, isLoading }: ChatMessageProps) {
  const isUser = role === 'user'
  
  return (
    <div className={`flex gap-4 mb-4 animate-fadeIn ${isUser ? 'flex-row-reverse' : ''}`}>
      {/* Avatar/Marker */}
      <div className={`flex-shrink-0 w-8 h-8 flex items-center justify-center border-2 ${
        isUser 
          ? 'border-primary text-primary' 
          : 'border-secondary text-secondary'
      }`}>
        <span className="text-xs font-bold">{isUser ? '>' : '$'}</span>
      </div>
      
      {/* Message Content */}
      <div className={`flex-1 ${isUser ? 'text-right' : ''}`}>
        <div className={`inline-block max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 border-2 ${
          isUser
            ? 'border-primary bg-black text-primary'
            : 'border-secondary bg-black text-secondary'
        }`}>
          <p className="text-sm md:text-base whitespace-pre-wrap break-words">
            {isLoading ? (
              <span className="inline-flex gap-1">
                <span className="animate-pulse">▮</span>
                <span className="animate-pulse animation-delay-100">▮</span>
                <span className="animate-pulse animation-delay-200">▮</span>
              </span>
            ) : (
              content
            )}
          </p>
        </div>
        <div className={`text-xs mt-1 ${isUser ? 'text-muted-foreground mr-2' : 'text-muted-foreground ml-2'}`}>
          {isUser ? 'USER' : 'LLAMA'}
        </div>
      </div>
    </div>
  )
}
