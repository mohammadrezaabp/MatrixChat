'use client'

import { useState, useEffect, useRef } from 'react'
import { ChatMessage } from '@/components/chat-message'
import { ChatInput } from '@/components/chat-input'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
}

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      role: 'assistant',
      content: `[SYSTEM INITIALIZED]
WELCOME TO MATRIX CHAT v1.0
Connected to: Llama 3.2
Status: ONLINE
Type your message and press ENTER to begin...`
    }
  ])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async (userMessage: string) => {
    // Add user message
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: userMessage
    }
    setMessages(prev => [...prev, userMsg])
    setIsLoading(true)
    setError(null)

    try {
      // Add loading message
      const loadingId = (Date.now() + 1).toString()
      const loadingMsg: Message = {
        id: loadingId,
        role: 'assistant',
        content: ''
      }
      setMessages(prev => [...prev, loadingMsg])

      // Call backend API
      const response = await fetch(`${API_URL}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: messages.map(msg => ({
            role: msg.role,
            content: msg.content
          })).concat([{
            role: 'user',
            content: userMessage
          }]),
          model: 'llama3.2',
          temperature: 0.7,
          top_p: 0.9
        })
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.detail || `API error: ${response.status}`)
      }

      const data = await response.json()
      
      // Replace loading message with actual response
      setMessages(prev => 
        prev.map(msg => 
          msg.id === loadingId 
            ? { ...msg, content: data.response }
            : msg
        )
      )
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to get response'
      setError(errorMessage)
      
      // Remove loading message on error
      setMessages(prev => prev.filter(msg => msg.role !== 'assistant' || msg.content))
      
      // Add error message
      setMessages(prev => [...prev, {
        id: (Date.now() + 2).toString(),
        role: 'assistant',
        content: `[ERROR]\n${errorMessage}\n\nMake sure the Python backend is running on port 8000 and Ollama is accessible.`
      }])
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-primary px-6 py-4">
        <h1 className="text-2xl font-bold font-mono text-primary glitch" data-text="MATRIX CHAT">
          MATRIX CHAT
        </h1>
        <p className="text-sm text-secondary mt-2">
          {'> '} Connected to Llama 3.2 via local Ollama instance
        </p>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4">
        {messages.map((message) => (
          <ChatMessage
            key={message.id}
            role={message.role}
            content={message.content}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Error Display */}
      {error && (
        <div className="mx-6 mb-4 p-3 border-2 border-destructive bg-black text-destructive text-sm">
          <span className="font-bold">⚠ ERROR:</span> {error}
        </div>
      )}

      {/* Input Area */}
      <div className="px-6 pb-6">
        <ChatInput 
          onSubmit={handleSendMessage}
          isLoading={isLoading}
        />
      </div>
    </main>
  )
}
